import React from 'react';
import { Container } from '@/components/ui/Container';
import { Button } from '@/components/ui/Button';

export const Hero = () => {
    return (
        <div className="relative bg-p44-navy text-white overflow-hidden">
            {/* Background Graphic Placeholder */}
            <div className="absolute inset-0 bg-gradient-to-r from-p44-navy via-p44-navy to-blue-900 opacity-80 z-0"></div>

            <Container className="relative z-10 py-24 md:py-32 lg:py-40">
                <div className="max-w-4xl mx-auto text-center">
                    <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-6 leading-tight">
                        The High-Velocity <br className="hidden md:block" />
                        <span className="text-blue-400">Supply Chain Platform</span>
                    </h1>
                    <p className="text-xl md:text-2xl text-gray-300 mb-10 max-w-2xl mx-auto">
                        Movement is the AI-powered Decision Intelligence Platform for the modern supply chain. Gain control with smart, intuitive solutions.
                    </p>
                    <div className="flex flex-col sm:flex-row justify-center gap-4">
                        <Button size="lg" className="bg-white text-p44-navy hover:bg-gray-100 border-none">
                            Get a Demo
                        </Button>
                        <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 hover:text-white">
                            Watch the Video
                        </Button>
                    </div>
                </div>
            </Container>
        </div>
    );
};
