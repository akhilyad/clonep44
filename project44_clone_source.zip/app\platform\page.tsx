import React from 'react';
import { Container } from '@/components/ui/Container';
import { Button } from '@/components/ui/Button';
import { siteContent } from '@/data/content';

export default function PlatformPage() {
    const { title, description, features } = siteContent.platform;

    return (
        <main className="bg-white">
            {/* Hero Section */}
            <div className="bg-p44-navy py-24 text-white">
                <Container>
                    <div className="max-w-3xl mx-auto text-center">
                        <h1 className="text-4xl md:text-5xl font-bold mb-6">{title}</h1>
                        <p className="text-xl text-gray-300 mb-8">{description}</p>
                        <Button size="lg" className="bg-white text-p44-navy hover:bg-gray-100">
                            Request a Demo
                        </Button>
                    </div>
                </Container>
            </div>

            {/* Features Grid */}
            <div className="py-24">
                <Container>
                    <div className="grid md:grid-cols-2 gap-12">
                        {features.map((feature, index) => {
                            const Icon = feature.icon;
                            return (
                                <div key={index} className="flex gap-6 p-6 rounded-2xl border border-gray-100 hover:shadow-lg transition-shadow">
                                    <div className="flex-shrink-0">
                                        <div className="w-12 h-12 bg-p44-light-blue rounded-full flex items-center justify-center">
                                            <Icon className="w-6 h-6 text-p44-blue" />
                                        </div>
                                    </div>
                                    <div>
                                        <h3 className="text-xl font-bold text-p44-navy mb-2">{feature.title}</h3>
                                        <p className="text-gray-600">{feature.description}</p>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </Container>
            </div>
        </main>
    );
}
