import React from 'react';
import { Container } from '@/components/ui/Container';

export default function CompanyPage() {
    return (
        <main className="min-h-screen bg-white">
            <div className="bg-p44-navy py-24 text-white">
                <Container>
                    <h1 className="text-4xl md:text-5xl font-bold mb-6">We move the world&apos;s data.</h1>
                    <p className="text-xl text-gray-300 max-w-2xl">
                        project44 is on a mission to make supply chains work. As the supply chain connective tissue, we optimize the movement of products globally.
                    </p>
                </Container>
            </div>
            <Container className="py-20">
                <div className="prose prose-lg max-w-4xl mx-auto text-gray-600">
                    <h2 className="text-3xl font-bold text-p44-navy">Our Story</h2>
                    <p>
                        Founded in Chicago, project44 has grown into the leading platform for supply chain visibility. We connect thousands of carriers and shippers, bringing transparency to an opaque industry.
                    </p>
                    <h2 className="text-3xl font-bold text-p44-navy mt-12">Our Values</h2>
                    <ul className="grid md:grid-cols-2 gap-6 list-none pl-0 mt-6">
                        <li className="p-6 border-l-4 border-p44-blue bg-gray-50">
                            <strong className="block text-p44-navy text-lg mb-2">Obsess over the customer</strong>
                            We exist to help our customers succeed.
                        </li>
                        <li className="p-6 border-l-4 border-p44-blue bg-gray-50">
                            <strong className="block text-p44-navy text-lg mb-2">Keep it real</strong>
                            Authenticity and transparency in everything we do.
                        </li>
                    </ul>
                </div>
            </Container>
        </main>
    );
}
