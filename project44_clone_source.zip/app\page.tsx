import { Hero } from "@/components/sections/Hero";
import { Stats } from "@/components/sections/Stats";
import { ValueProp } from "@/components/sections/ValueProp";

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <Hero />
      <Stats />
      <ValueProp />
    </main>
  );
}
