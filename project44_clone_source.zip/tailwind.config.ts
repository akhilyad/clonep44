import type { Config } from "tailwindcss";

const config: Config = {
    content: [
        "./pages/**/*.{js,ts,jsx,tsx,mdx}",
        "./components/**/*.{js,ts,jsx,tsx,mdx}",
        "./app/**/*.{js,ts,jsx,tsx,mdx}",
    ],
    theme: {
        extend: {
            colors: {
                p44: {
                    navy: "#0a192f", // Deep navy background often seen in enterprise tech
                    blue: "#0052cc", // Primary accent blue
                    "light-blue": "#e6f0ff", // Light blue background
                    gray: "#f4f5f7", // Light gray background
                    text: "#172b4d", // Main text color
                    "text-light": "#6b778c", // Secondary text
                },
            },
            backgroundImage: {
                "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
                "gradient-conic":
                    "conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))",
            },
            fontFamily: {
                sans: ['var(--font-geist-sans)', 'sans-serif'], // Using the nextjs/font generic variable for now, will map Inter in layout
            },
        },
    },
    plugins: [],
};
export default config;
