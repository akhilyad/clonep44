import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    variant?: 'primary' | 'secondary' | 'outline' | 'text';
    size?: 'sm' | 'md' | 'lg';
    fullWidth?: boolean;
    children: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
    variant = 'primary',
    size = 'md',
    fullWidth = false,
    className = '',
    children,
    ...props
}) => {
    const baseStyles = 'inline-flex items-center justify-center font-semibold transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 rounded-full';

    const variants = {
        primary: 'bg-p44-blue hover:bg-blue-700 text-white focus:ring-blue-500',
        secondary: 'bg-white text-p44-text hover:bg-gray-50 border border-gray-300 focus:ring-gray-500',
        outline: 'border-2 border-p44-blue text-p44-blue hover:bg-p44-blue hover:text-white',
        text: 'text-p44-blue hover:underline bg-transparent shadow-none',
    };

    const sizes = {
        sm: 'px-4 py-2 text-sm',
        md: 'px-6 py-3 text-base',
        lg: 'px-8 py-4 text-lg',
    };

    const widthStyles = fullWidth ? 'w-full' : '';

    return (
        <button
            className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${widthStyles} ${className}`}
            {...props}
        >
            {children}
        </button>
    );
};
