import React from 'react';
import { Container } from '@/components/ui/Container';
import { siteContent } from '@/data/content';

export default function SolutionsPage() {
    const { solutions } = siteContent;

    return (
        <main className="bg-white min-h-screen">
            <div className="bg-gray-50 py-20 border-b border-gray-200">
                <Container>
                    <h1 className="text-4xl font-bold text-p44-navy mb-4">Solutions by Industry</h1>
                    <p className="text-lg text-gray-600 max-w-2xl">
                        Tailored supply chain solutions to meet the unique challenges of your sector.
                    </p>
                </Container>
            </div>

            <div className="py-24">
                <Container>
                    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                        {solutions.map((solution, index) => {
                            const Icon = solution.icon;
                            return (
                                <div key={index} className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:border-p44-blue transition-colors group">
                                    <Icon className="w-10 h-10 text-p44-text group-hover:text-p44-blue mb-6 transition-colors" />
                                    <h3 className="text-xl font-bold text-p44-text mb-3">{solution.title}</h3>
                                    <p className="text-gray-500 leading-relaxed">{solution.description}</p>
                                </div>
                            );
                        })}
                    </div>
                </Container>
            </div>
        </main>
    );
}
