import React from 'react';
import { Container } from '@/components/ui/Container';

export default function ResourcesPage() {
    return (
        <main className="min-h-screen bg-gray-50">
            <div className="bg-white border-b border-gray-200 py-20">
                <Container>
                    <h1 className="text-4xl font-bold text-p44-navy mb-4">Resources</h1>
                    <p className="text-lg text-gray-600">
                        Insights, reports, and guides for the modern supply chain.
                    </p>
                </Container>
            </div>

            <Container className="py-16">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {[1, 2, 3, 4, 5, 6].map((i) => (
                        <div key={i} className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100 hover:shadow-md transition-shadow">
                            <div className="h-48 bg-gray-200 animate-pulse"></div>
                            <div className="p-6">
                                <div className="text-xs font-bold text-p44-blue uppercase mb-2">Report</div>
                                <h3 className="text-xl font-bold text-p44-navy mb-3">Supply Chain Trends 202{i}</h3>
                                <p className="text-gray-600 mb-4">Latest insights into global logistics performance and predictive analytics...</p>
                                <a href="#" className="text-p44-blue font-semibold hover:underline">Read more &rarr;</a>
                            </div>
                        </div>
                    ))}
                </div>
            </Container>
        </main>
    );
}
