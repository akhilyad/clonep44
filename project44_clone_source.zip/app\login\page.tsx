import React from 'react';
import { Container } from '@/components/ui/Container';
import { Button } from '@/components/ui/Button';

export default function LoginPage() {
    return (
        <main className="min-h-screen bg-gray-50 flex items-center justify-center py-20">
            <div className="max-w-md w-full bg-white p-8 rounded-2xl shadow-lg border border-gray-100">
                <div className="text-center mb-8">
                    <h1 className="text-2xl font-bold text-p44-navy">Sign In</h1>
                    <p className="text-gray-500">Access your Movement platform account</p>
                </div>

                <form className="space-y-6">
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                        <input
                            type="email"
                            id="email"
                            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-p44-blue focus:border-transparent outline-none transition-all"
                            placeholder="you@company.com"
                        />
                    </div>
                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                        <input
                            type="password"
                            id="password"
                            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-p44-blue focus:border-transparent outline-none transition-all"
                            placeholder="••••••••"
                        />
                    </div>
                    <div className="flex items-center justify-between text-sm">
                        <label className="flex items-center">
                            <input type="checkbox" className="rounded border-gray-300 text-p44-blue focus:ring-p44-blue" />
                            <span className="ml-2 text-gray-600">Remember me</span>
                        </label>
                        <a href="#" className="text-p44-blue hover:underline">Forgot password?</a>
                    </div>

                    <Button fullWidth size="lg">Sign In</Button>

                    <p className="text-center text-sm text-gray-500">
                        Don&apos;t have an account? <a href="#" className="text-p44-blue font-semibold hover:underline">Contact Sales</a>
                    </p>
                </form>
            </div>
        </main>
    );
}
