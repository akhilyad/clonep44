import { Truck, Globe, BarChart3, ShieldCheck, Box, Zap, ShoppingCart, Anchor } from 'lucide-react';

export const siteContent = {
    hero: {
        title: "The High-Velocity Supply Chain Platform",
        subtitle: "Movement is the AI-powered Decision Intelligence Platform for the modern supply chain. Gain control with smart, intuitive solutions.",
        ctaPrimary: "Get a Demo",
        ctaSecondary: "Watch the Video",
    },
    stats: [
        { label: 'Shipments Tracked', value: '1.5B+' },
        { label: 'Carriers', value: '240k+' },
        { label: 'Countries', value: '184' },
        { label: 'Customers', value: '1,300+' },
    ],
    homeFeatures: [
        {
            title: 'Connect everything.',
            description: 'We built the industry&rsquo;s most advanced platform to connect carriers, freight forwarders, and shippers across all modes of transportation.',
            buttonText: 'Explore Connectivity',
            image: '/images/network_connectivity_abstract_1769792802896.png', // Update with actual filename after copy
            imageSide: 'right',
        },
        {
            title: 'See clearly.',
            description: 'Gain real-time visibility into your inventory in motion. From raw materials to the end consumer, see it all in one place with predictive ETAs.',
            buttonText: 'View Visibility Solutions',
            image: '/images/shipment_visibility_ui_1769792817899.png',
            imageSide: 'left',
        },
        {
            title: 'Act decisively.',
            description: 'Turn insights into action. Our Decision Intelligence helps you mitigate disruptions and optimize performance dynamically with AI-driven recommendations.',
            buttonText: 'Learn About Intelligence',
            image: '/images/supply_chain_dashboard_1769792790539.png',
            imageSide: 'right',
        },
    ],
    platform: {
        title: "Movement: The Decision Intelligence Platform",
        description: "One platform to manage your entire supply chain. From first mile to last mile, and everything in between.",
        features: [
            {
                title: "Real-Time Visibility",
                description: "Track shipments across all modes and geographies with high-fidelity data.",
                icon: Globe,
            },
            {
                title: "Workflow Automation",
                description: "Automate manual tasks and exception management to save time and reduce errors.",
                icon: Zap,
            },
            {
                title: "Carrier Connectivity",
                description: "Access the world's largest carrier network via API or EDI integration.",
                icon: Truck,
            },
            {
                title: "Data Intelligence",
                description: "Leverage AI/ML to predict ETAs, detention costs, and carbon emissions.",
                icon: BarChart3,
            },
        ],
    },
    solutions: [
        {
            title: "Retail & eCommerce",
            description: "Deliver superior customer experiences with precise delivery promises and tracking.",
            icon: ShoppingCart,
        },
        {
            title: "Manufacturing",
            description: "Keep production lines running by ensuring raw materials arrive on time.",
            icon: Box,
        },
        {
            title: "Food & Beverage",
            description: "Ensure freshness and compliance with temperature monitoring and fast transit.",
            icon: ShieldCheck,
        },
        {
            title: "Logistics Service Providers",
            description: "Empower your teams with the visibility they need to serve your customers better.",
            icon: Anchor,
        },
    ],
};
