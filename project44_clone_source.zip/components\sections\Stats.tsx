import React from 'react';
import { Container } from '@/components/ui/Container';

const stats = [
    { label: 'Shipments Tracked', value: '1.5B+' },
    { label: 'Carriers', value: '240k+' },
    { label: 'Countries', value: '184' },
    { label: 'Customers', value: '1,300+' },
];

export const Stats = () => {
    return (
        <div className="bg-p44-navy text-white py-16 border-t border-white/10">
            <Container>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                    {stats.map((stat) => (
                        <div key={stat.label} className="p-4">
                            <div className="text-4xl md:text-5xl font-bold text-blue-400 mb-2">{stat.value}</div>
                            <div className="text-sm uppercase tracking-wider text-gray-400 font-semibold">{stat.label}</div>
                        </div>
                    ))}
                </div>
            </Container>
        </div>
    );
};
