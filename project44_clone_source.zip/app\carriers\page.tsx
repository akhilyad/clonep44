import React from 'react';
import { Container } from '@/components/ui/Container';
import { Button } from '@/components/ui/Button';

export default function CarriersPage() {
    return (
        <main className="min-h-screen bg-white">
            <div className="bg-p44-navy py-24 text-white">
                <Container>
                    <div className="max-w-3xl mx-auto text-center">
                        <h1 className="text-4xl md:text-5xl font-bold mb-6">Drive with project44</h1>
                        <p className="text-xl text-gray-300 mb-8">
                            Join the world&apos;s largest carrier network. Connect once, share everywhere.
                        </p>
                        <div className="flex justify-center gap-4">
                            <Button size="lg" className="bg-white text-p44-navy hover:bg-gray-100">
                                Join the Network
                            </Button>
                            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                                Carrier Login
                            </Button>
                        </div>
                    </div>
                </Container>
            </div>
            <Container className="py-20 text-center">
                <h2 className="text-3xl font-bold text-p44-navy mb-8">Why join?</h2>
                <div className="grid md:grid-cols-3 gap-8">
                    <div className="p-6 bg-gray-50 rounded-xl">
                        <h3 className="text-xl font-bold mb-2">Eliminate Manual Calls</h3>
                        <p className="text-gray-600">Automated tracking means fewer check-calls and more driving.</p>
                    </div>
                    <div className="p-6 bg-gray-50 rounded-xl">
                        <h3 className="text-xl font-bold mb-2">Get Paid Faster</h3>
                        <p className="text-gray-600">Digital proof of delivery triggers faster payment processing.</p>
                    </div>
                    <div className="p-6 bg-gray-50 rounded-xl">
                        <h3 className="text-xl font-bold mb-2">Premium Loads</h3>
                        <p className="text-gray-600">Access exclusive freight opportunities from top shippers.</p>
                    </div>
                </div>
            </Container>
        </main>
    );
}
