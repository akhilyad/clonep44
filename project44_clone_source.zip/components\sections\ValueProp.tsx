import React from 'react';
import Image from 'next/image';
import { Container } from '@/components/ui/Container';
import { Button } from '@/components/ui/Button';
import { siteContent } from '@/data/content';

export const ValueProp = () => {
    return (
        <div className="py-24 bg-white">
            <Container>
                <div className="space-y-32">
                    {siteContent.homeFeatures.map((feature, index) => (
                        <div
                            key={index}
                            className={`flex flex-col md:flex-row items-center gap-12 lg:gap-24 ${feature.imageSide === 'left' ? 'md:flex-row-reverse' : ''
                                }`}
                        >
                            <div className="flex-1 space-y-6">
                                <h2 className="text-3xl md:text-5xl font-bold text-p44-navy leading-tight">
                                    {feature.title}
                                </h2>
                                <p className="text-lg text-gray-600 leading-relaxed">
                                    {feature.description}
                                </p>
                                <Button variant="outline" size="lg" className="mt-4">
                                    {feature.buttonText}
                                </Button>
                            </div>

                            {/* Image Section */}
                            <div className="flex-1 w-full relative group">
                                <div className="aspect-[4/3] relative rounded-2xl overflow-hidden shadow-2xl border border-gray-100 bg-gray-50">
                                    <Image
                                        src={feature.image}
                                        alt={feature.title}
                                        fill
                                        className="object-cover object-center group-hover:scale-105 transition-transform duration-700"
                                    />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </Container>
        </div>
    );
};
