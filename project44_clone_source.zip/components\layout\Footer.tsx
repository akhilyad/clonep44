import React from 'react';
import Link from 'next/link';
import { Container } from '@/components/ui/Container';

export const Footer = () => {
    const footerSections = [
        {
            title: 'Platform',
            links: [
                { name: 'Movement', href: '#' },
                { name: 'Visibility', href: '#' },
                { name: 'Transportation Management', href: '#' },
                { name: 'Yard Management', href: '#' },
            ],
        },
        {
            title: 'Company',
            links: [
                { name: 'About Us', href: '#' },
                { name: 'Careers', href: '#' },
                { name: 'Newsroom', href: '#' },
                { name: 'Contact', href: '#' },
            ],
        },
        {
            title: 'Resources',
            links: [
                { name: 'Blog', href: '#' },
                { name: 'Case Studies', href: '#' },
                { name: 'Events', href: '#' },
                { name: 'Documentation', href: '#' },
            ],
        },
        {
            title: 'Connect',
            links: [
                { name: 'LinkedIn', href: '#' },
                { name: 'Twitter', href: '#' },
                { name: 'YouTube', href: '#' },
            ],
        },
    ];

    return (
        <footer className="bg-p44-navy text-white py-16">
            <Container>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
                    {footerSections.map((section) => (
                        <div key={section.title}>
                            <h3 className="text-lg font-bold mb-6 text-white">{section.title}</h3>
                            <ul className="space-y-4">
                                {section.links.map((link) => (
                                    <li key={link.name}>
                                        <Link href={link.href} className="text-gray-300 hover:text-white transition-colors">
                                            {link.name}
                                        </Link>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ))}
                </div>
                <div className="border-t border-gray-700 pt-8 flex flex-col md:flex-row justify-between items-center text-gray-400 text-sm">
                    <p>© {new Date().getFullYear()} project44. All rights reserved.</p>
                    <div className="flex space-x-6 mt-4 md:mt-0">
                        <Link href="#" className="hover:text-white">Privacy Policy</Link>
                        <Link href="#" className="hover:text-white">Terms of Use</Link>
                        <Link href="#" className="hover:text-white">Legal</Link>
                    </div>
                </div>
            </Container>
        </footer>
    );
};
