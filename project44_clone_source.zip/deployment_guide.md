# Deployment Guide for Project44 Clone

Your Application is ready for deployment! Since it is built with **Next.js 14**, you have several excellent options for hosting.

## Option 1: Vercel (Recommended)
The creators of Next.js provide the best hosting experience with zero configuration.

1.  **Push to GitHub/GitLab/Bitbucket**:
    - Initialize git: `git init`, `git add .`, `git commit -m "Initial commit"`
    - Push to your repository.
2.  **Import to Vercel**:
    - Go to [vercel.com](https://vercel.com) and sign up/login.
    - Click **"Add New..."** -> **"Project"**.
    - Import your git repository.
    - **Build Settings**: Vercel detects Next.js automatically. No changes needed.
    - Click **Deploy**.

## Option 2: Netlify
1.  **Push to Git** (Same as above).
2.  **New Site from Git**:
    - Go to [netlify.com](https://netlify.com).
    - "Import from Git".
    - **Build Command**: `npm run build`
    - **Publish Directory**: `.next` (or let Netlify auto-detect Next.js runtime).

## Option 3: Docker (Self-Hosted)
I have ensured the project can be containerized. Create a `Dockerfile` in the project root:

```dockerfile
FROM node:18-alpine AS base

# Install dependencies only when needed
FROM base AS deps
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci

# Rebuild the source code only when needed
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

# Production image, copy all the files and run next
FROM base AS runner
WORKDIR /app
ENV NODE_ENV production
COPY --from=builder /app/public ./public
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static

EXPOSE 3000
CMD ["node", "server.js"]
```

## Pre-Deployment Checklist
- [x] **Build Check**: `npm run build` passed.
- [ ] **Environment Variables**: This project currently uses static data (`data/content.ts`), so no `.env` variables are required yet.
- [ ] **Linting**: Run `npm run lint` to catch any last-minute issues.
